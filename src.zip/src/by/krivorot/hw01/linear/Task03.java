package by.krivorot.hw01.linear;

public class Task03 {

	public static void main(String[] args) {
		// Найдите значение функции: z = 2 * x + ( y - 2 ) * 5.

		double x = 4;
		double y = 1;
		double z;

		z = 2 * x + (y - 2) * 5;
		
		System.out.println("z = " + z);

	}

}
