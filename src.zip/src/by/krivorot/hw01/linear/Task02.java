package by.krivorot.hw01.linear;

public class Task02 {

	public static void main(String[] args) {
		//  Найдите значение функции: с = 3 + а.

		double a = 4.3;
		double c;

		c = 3 + a;

		System.out.println("c = " + c);
	}

}
