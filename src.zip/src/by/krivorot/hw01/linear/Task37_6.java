package by.krivorot.hw01.linear;

public class Task37_6 {

	public static void main(String[] args) {
		/*
		 * Составить линейную программу, печатающую значение true, если указанное
		 * высказывание является истинным, и false — в противном случае: Треугольник со
		 * сторонами а,b,с является равнобедренным.
		 */

		int a = 3;
		int b = 4;
		int c = 5;

		System.out.println((a == c) || (a == b) || (b == c));

	}

}
