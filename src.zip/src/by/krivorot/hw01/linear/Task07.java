package by.krivorot.hw01.linear;

public class Task07 {

	public static void main(String[] args) {
		/*
		 * Дан прямоугольник, ширина которого в два раза меньше длины. Найти площадь
		 * прямоугольника
		 */

		double a = 4;

		System.out.println("Площадь прямоугольника " + (a * a / 2));
	}

}
