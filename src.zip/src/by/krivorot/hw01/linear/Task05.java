package by.krivorot.hw01.linear;

public class Task05 {

	public static void main(String[] args) {
		// Составить алгоритм нахождения среднего арифметического двух чисел

		double a = -2;
		double b = 0;
		double c;

		c = (a + b) / 2;
		
		System.out.println("c = " + c);

	}

}
