package by.krivorot.hw01.linear;

public class Task04 {

	public static void main(String[] args) {
		// Найдите значение функции: z = ( (a – 3 ) * b / 2) + c.

		double a = 2.0;
		double b = 1.0;
		double c = 3.0;
		double z;

		z = ((a - 3) * b / 2) + c;

		System.out.println("z = " + z);

	}

}
