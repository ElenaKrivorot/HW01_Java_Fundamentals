package by.krivorot.hw01.linear;

public class Task01 {

	public static void main(String[] args) {
		/*
		 * Даны два действительных числа х и у. Вычислить их сумму, разность,
		 * произведение и частное.
		 */

		int x = 12;
		int y = 4;

		System.out.println("x + y = " + (x + y));
		System.out.println("x + y = " + (x - y));
		System.out.println("x + y = " + (x * y));
		System.out.println("x + y = " + (x / y));

	}

}
