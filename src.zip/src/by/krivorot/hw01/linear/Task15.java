package by.krivorot.hw01.linear;

public class Task15 {

	public static void main(String[] args) {
		/*
		 * Написать программу, которая выводит на экран первые четыре степени числа π.
		 */

		System.out.println("π^1 = " + (Math.PI));
		System.out.println("π^2 = " + (Math.pow(Math.PI, 2)));
		System.out.println("π^3 = " + (Math.pow(Math.PI, 3)));
		System.out.println("π^4 = " + (Math.pow(Math.PI, 4)));

	}

}
